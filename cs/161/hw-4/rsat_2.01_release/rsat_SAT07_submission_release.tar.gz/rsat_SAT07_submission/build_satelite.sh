#!/bin/sh
cd SatEliteCode
./clean.sh
./build.sh
