#include <limits.h>

typedef unsigned int CNF_VAR_INDEX;
typedef signed int CNF_LITERAL_INDEX;
typedef unsigned long CNF_CLAUSE_INDEX;
typedef unsigned int CNF_CLAUSE_SIZE;
typedef unsigned long CLAUSE_MARK;
typedef unsigned long VAR_MARK;
typedef unsigned long LITERAL_MARK;
typedef char BOOLEAN;
typedef unsigned char MEMORY_TYPE;

typedef int my_var;
typedef int my_lit;
